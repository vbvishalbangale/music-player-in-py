import math


def square_root(x):
    y = math.sqrt(x)
    return y
