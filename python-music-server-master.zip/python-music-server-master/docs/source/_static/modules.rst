PythonMusicPlayer
=================

.. toctree::
   :maxdepth: 4

   mpserver
